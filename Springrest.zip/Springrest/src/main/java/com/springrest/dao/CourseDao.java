package com.springrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.springrest.entity.Course;

import jakarta.transaction.Transactional;

public interface CourseDao extends JpaRepository<Course, Long> {
	//@Query(value="SELECT s FROM Course s")
	//@Query("DELETE FROM Course c WHERE c.id = :id")
	//public List<Course> fetchallFromCustom();

	@Transactional
	@Modifying
	 @Query("DELETE FROM Course u WHERE u.id=?1")
	    public void deleteById(long id);
}



